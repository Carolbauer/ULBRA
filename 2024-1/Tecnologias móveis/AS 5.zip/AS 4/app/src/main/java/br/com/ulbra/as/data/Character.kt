package br.com.ulbra.`as`.data

data class Character(
    val name: String,
    val image: String,
)
