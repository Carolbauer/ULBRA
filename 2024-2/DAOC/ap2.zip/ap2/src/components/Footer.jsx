function Footer() {
  return (
    <footer>
      <p>Curso de Análise e Desenvolvimento de Sistemas</p>
        <p> ULBRA/TORRES</p>
    </footer>
  );
}

export default Footer;