function Header(){
  return(
      <div className="header">
          <h1>Entrevero</h1>    
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLIaWSHOIoO6Lr2CXfqhQMpy8inASN4v6zvA&s" alt="Logo" className="header-logo"/>
      </div>
  )
}

export default Header;