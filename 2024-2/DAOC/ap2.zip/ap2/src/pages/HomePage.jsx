import AllInfos from '../components/AllInfos';
const HomePage = () => {
    return (
        <div>
            <AllInfos 
            name = "Caroline Bauer"
            horario = "19:00"
            logradouro = "Rua Universitária, 234"
            local = "Sede da Brigada militar"
            />
        </div>
    )
    }

export default HomePage;