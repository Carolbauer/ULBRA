public class Programa {
    public static void main(String[] args) {
        Livro livro1 = new Livro("Java", "Lucas");
        System.out.println(livro1.getTitulo() + " " + livro1.getAutor() + " " + livro1.getPreco());
    }


}
