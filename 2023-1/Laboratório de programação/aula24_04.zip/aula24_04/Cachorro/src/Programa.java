public class Programa {
    public static void main(String[] args) {
        Cachorro cachorro1 = new Cachorro("Sadan", "pequines");
        System.out.println(cachorro1.getNome() + " " + cachorro1.getRaca() + " " + cachorro1.getPreco());
    }



}
