public interface Treinavel {
    public void realizarTruque();
}
