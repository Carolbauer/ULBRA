public class teste {
    ublic static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
