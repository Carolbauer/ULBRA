package br.com.ulbra.ap2.dtos;


import br.com.ulbra.ap2.entities.Client;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ClientResponseDto {
    private String profession;
    private String name;
    private int age;

    public ClientResponseDto(Client client) {
        this.profession = client.getProfession();
        this.name = client.getName();
        this.age = client.getAge();


    }

    public ClientResponseDto(final String name, int age, String profession) {
    }
}


