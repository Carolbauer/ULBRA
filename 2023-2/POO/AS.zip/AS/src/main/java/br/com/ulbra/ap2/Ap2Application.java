package br.com.ulbra.ap2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
class Ap2Application {

    public static void main(final String[] args) {
        SpringApplication.run(Ap2Application.class, args);
    }

}
