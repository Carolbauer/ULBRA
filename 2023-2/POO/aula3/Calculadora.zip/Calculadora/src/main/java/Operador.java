import java.util.ArrayList;

public interface Operador {
    double calcular(ArrayList<Double> lista);
}
