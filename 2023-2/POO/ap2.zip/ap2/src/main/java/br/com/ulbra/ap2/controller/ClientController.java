package br.com.ulbra.ap2.controller;

import br.com.ulbra.ap2.models.Client;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/clients")
public class ClientController {
    private final List<Client> clients = new ArrayList<>();
    private final int nextId = 1;

}
