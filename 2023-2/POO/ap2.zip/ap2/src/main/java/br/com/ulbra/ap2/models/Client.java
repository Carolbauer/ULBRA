package br.com.ulbra.ap2.models;

public class Client {
    private long id;
    private String name;
    private int age;
    private String profession;

    public Client(final int id, final String name, final int age, final String profession) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.profession = profession;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }
}